//
//  main.m
//  ZCJTemplateTool
//
//  Created by inpark_1 on 2017/2/24.
//  Copyright © 2017年 inpark. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
