//
//  MGTemplateStandardFilters.h
//
//  Created by Matt Gemmell on 13/05/2008.
//  Copyright 2008 Instinctive Code. All rights reserved.
//

#import "MGTemplateFilter.h"


@interface MGTemplateStandardFilters : NSObject <MGTemplateFilter> {

}

@end
